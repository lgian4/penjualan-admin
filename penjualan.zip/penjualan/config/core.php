<?php
// page given in URL parameter, default page is one

session_start();
if(isset($_SESSION['level']) && $_SESSION["level"] != "super"   && $_SESSION["level"] != "admin"  ){
	header("location:login.php");
}
?>