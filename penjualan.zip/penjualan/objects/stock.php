<?php

class Stock{

	private $id;
	private $product_id;
	private $debit;
	private $kredit;
	private $description;
	private $price;
	private $base_price;
	private $date;
	private $user_id;
    private $customer_id;
    private $stock_id;
    private $sale_id;   
	private $conn;
	public $tblName = "tbl_stock";
	private $none;
	

	function __construct($db,$none = "NaN"){
		$this->conn = $db;
		 $this->setNone($none);
	}
	//get
	public function getId(){
		 if($this->id != ""){
            return $this->id;
        }
        else{
            return $this->none;
        } 
	}
	public function getProductId(){
		if($this->product_id > 0){
            return $this->product_id;
        }
        else{
            return 0;
        }
	}
	public function getDebit(){
		if($this->debit > 0){
            return $this->debit;
        }
        else{
            return 0;
        }
	}
	public function getKredit(){
        if($this->kredit > 0){
            return $this->kredit;
        }
        else{
            return 0;
        }
    }
	public function getDescription(){
		if($this->description != ""){
            return $this->description;
        }
        else{
            return $this->none;
        }
	}
	public function getPrice(){
        if($this->price > 0){
            return $this->price;
        }
        else{
            return 0;
        }
    }
	public function getBasePrice(){
        if($this->base_price > 0){
            return $this->base_price;
        }
        else{
            return 0;
        }
    }
	 public function getCurentDate(){
        return date('Y-m-d H:i:s');
    } 
    public function getdate(){
        if($this->date <= $this->getCurentDate()){
            return $this->date;
        }
        else{
            return $this->getCurentDate();
        }
    }
	public function getUserId(){
         if($this->user_id > 0  ){
            return $this->user_id;
        }
        else{
            return $this->none;
        } 
    }
    public function getCustomerId(){
         if($this->customer_id > 0  ){
            return $this->customer_id;
        }
        else{
            return $this->none;
        } 
    }
    public function getStockId(){
         if($this->stock_id > 0  ){
            return $this->stock_id;
        }
        else{
            return $this->none;
        } 
    }
    public function getSaleId(){
         if($this->sale_id > 0  ){
            return $this->sale_id;
        }
        else{
            return $this->none;
        } 
    }
	///set
	public function setNone($none){
        $none = trim($none);
        if($none  != ""){
            $this->none = $none;
        }
        else{
            $this->none = "NaN";
        }
    }
	public function setId($id){
        $id = htmlspecialchars(strip_tags(trim($id)));
		if(trim($id) > 0){
			$this->id = $id ;
		}
	}
    public function setProductId($id){
        $id = htmlspecialchars(strip_tags(trim($id)));
        if(trim($id) > 0){
            $this->product_id = $id ;
        }
    }
    public function setDebit($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->debit = $var ;
        }
    }
    public function setKredit($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->kredit = $var ;
        }
    }
    public function setDescription($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) != ""){
            $this->description = $var ;
        }
    }
    public function setPrice($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->price = $var ;
        }
    }
    public function setBasePrice($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->base_price = $var ;
        }
    }
    public function setDate($var){
          if($var <= $this->getCurentDate()){
             $this->date = $var;
        }
        else{
           $this->date =  $this->getCurentDate();
        }
    }
    public function setUserId($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->user_id = $var ;
        }
    }
    public function setCustomerId($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->customer_id = $var ;
        }
    }
    public function setStockId($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->stock_id = $var ;
        }
    }
    public function setSaleId($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->sale_id = $var ;
        }
    }   

	

	//
	
	public function countAll(){
 
    $query = "SELECT id FROM " . $this->tblName . "";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    $num = $stmt->rowCount();
 
    return $num;
}
	public function readOne($id){
		$this->setId($id);

		$query = "SELECT
		`id`, `product_id`, `debit`, `kredit`, `description`, `price`, `base_price`, `date`, `user_id`, `customer_id`, `stock_id`, `sale_id`
		   FROM " . $this->tblName . " WHERE id = :id ";
		$stmt = $this->conn->prepare( $query );
		$id = $this->getId();
	    $stmt->bindParam(':id', $id);
	    $stmt->execute();
 		
 		//
 		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
	        $this->setId($row['id']);
	        $this->setProductId($row['product_id']);
	        $this->setDebit($row['debit']);
	        $this->setKredit($row['kredit']);
	        $this->setDescription($row['description']);
            $this->setPrice($row['price']);
	        $this->setBasePrice($row['base_price']);
	        $this->setDate($row['date']);
	        $this->setUserId($row['user_id']);
	        $this->setCustomerId($row['customer_id']);
            $this->setStockId($row['stock_id']);
            $this->setSaleId($row['sale_id']);
	        $result['id'] = $this->getId();
	        $result['product_id'] = $this->getProductId();
	        $result['debit'] = $this->getDebit();
	        $result['kredit'] = $this->getKredit();
	        $result['description'] = $this->getDescription();
            $result['price'] = $this->getPrice();
	        $result['base_price'] = $this->getBasePrice();
	        $result['date'] = $this->getdate();
	        $result['user_id'] = $this->getUserId();
	        $result['customer_id'] = $this->getCustomerId();
            $result['stock_id'] = $this->getStockId();
            $result['sale_id'] = $this->getSaleId();
	        
        }
        return $result; 
	}
	public function readAll(){
        //select all data
        $query = "SELECT
                  `id`, `product_id`, `debit`, `kredit`, `description`, `price`, `base_price`, `date`, `user_id`, `customer_id`, `stock_id`, `sale_id`
                FROM
                    " . $this->tblName . "
                    
                ORDER BY
                   date";  
 
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
 		$a = 0;
        while ($row =$stmt->fetch(PDO::FETCH_ASSOC)) {
	        $this->setId($row['id']);
            $this->setProductId($row['product_id']);
            $this->setDebit($row['debit']);
            $this->setKredit($row['kredit']);
            $this->setDescription($row['description']);
            $this->setPrice($row['price']);
            $this->setBasePrice($row['base_price']);
            $this->setDate($row['date']);
            $this->setUserId($row['user_id']);
            $this->setCustomerId($row['customer_id']);
            $this->setStockId($row['stock_id']);
            $this->setSaleId($row['sale_id']);
            $result[$a]['id'] = $this->getId();
            $result[$a]['product_id'] = $this->getProductId();
            $result[$a]['debit'] = $this->getDebit();
            $result[$a]['kredit'] = $this->getKredit();
            $result[$a]['description'] = $this->getDescription();
            $result[$a]['price'] = $this->getPrice();
            $result[$a]['base_price'] = $this->getBasePrice();
            $result[$a]['date'] = $this->getdate();
            $result[$a]['user_id'] = $this->getUserId();
            $result[$a]['customer_id'] = $this->getCustomerId();
            $result[$a]['stock_id'] = $this->getStockId();
            $result[$a]['sale_id'] = $this->getSaleId();
	        $a++;
        }
        return $result; 
    }
	 function add($product_id, $debit,$price,$base_price,$user_id){
        $this->setProductId($product_id);
        $this->setDebit($debit);
        $this->setKredit($kredit);
        $this->setPrice($price);
        $this->setBasePrice($base_price);
        $this->setUserId($user_id);
        $query = "INSERT INTO " . $this->tblName . "
            SET product_id= :product_id,  debit= :debit, description ='add'  price= :price , base_price= :base_price , user_id= :user_id  ";
        $stmt = $this->conn->prepare($query);
        $product_id = $this->getProductId();
        $debit = $this->getDebit();
        $price = $this->getPrice();
        $base_price = $this->getBasePrice();
        $user_id = $this->getUserId();
        // bind values 
        $stmt->bindParam(":product_id",$product_id  );
        $stmt->bindParam(":debit",$debit );
        $stmt->bindParam(":price",$price );
        $stmt->bindParam(":base_price",$base_price );
        $stmt->bindParam(":user_id",$user_id );
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    function adjust($product_id,  $kredit,$price,$base_price,$user_id, $stock_id){
        $this->setProductId($product_id);
        $this->setKredit($kredit);
        $this->setPrice($price);
        $this->setBasePrice($base_price);
        $this->setUserId($user_id);
        $this->setStockId($stock_id);
        $query = "INSERT INTO " . $this->tblName . "
            SET product_id= :product_id,  kredit = :kredit, description ='adjust'  price= :price , base_price= :base_price , user_id= :user_id  , stock_id= :user_id ";
        $stmt = $this->conn->prepare($query);
        $product_id = $this->getProductId();
        $kredit = $this->getKredit();
        $price = $this->getPrice();
        $base_price = $this->getBasePrice();
        $user_id = $this->getUserId();
        // bind values 
        $stmt->bindParam(":product_id",$product_id  );
        $stmt->bindParam(":kredit",$kredit );
        $stmt->bindParam(":price",$price );
        $stmt->bindParam(":base_price",$base_price );
        $stmt->bindParam(":user_id",$user_id );
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    
  
    
 }