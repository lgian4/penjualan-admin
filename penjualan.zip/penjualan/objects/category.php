<?php
class Category{
 
    // database connection and table name
    private $conn;
    private $tblName = "tbl_category";
    private $none;
    // object properties
    private $id;
    private $name;
    private $description;
   
    public function __construct($db, $none = "NaN"){
        $this->conn = $db;
        $this->setNone($none);
    }
    public function getId(){
        if($this->id != ""){
            return htmlspecialchars(strip_tags($this->id));
        }
        else{
            return $this->none;
        }  
    }
    public function getName(){
         if($this->name != ""){
            return htmlspecialchars(strip_tags($this->name));
        }
        else{
            return $this->none;
        }
    }
    public function getDescription(){
        if($this->description != ""){
            return htmlspecialchars(strip_tags($this->description));
        }
        else{
            return $this->none;
        }
    }
    public function setId($id){
        $id = trim($id);
        if ($id != ""){
            $this->id = htmlspecialchars(strip_tags($id));
        }
        else{
            $this->id = $this->none;
        }   
    }
    public function setNone($none){
        $none = trim($none);
        if($none  != ""){
            $this->none = $none;
        }
        else{
            $this->none = "NaN";
        }
    }
	public function setName($name){
		$name = trim($name);
        if ($name != ""){
            $this->name = htmlspecialchars(strip_tags($name));
        }
        else{
            $this->name = $this->none;
        }
	}
	public function setDescription($description){
		$description = trim($description);
        if ($description != ""){
            $this->description = htmlspecialchars(strip_tags($description));
        }
        else{
            $this->description = $this->none;
        }
				
	}
    // used by select drop-down list
    public function readAll(){
        //select all data
        $query = "SELECT
                    id, name, description
                FROM
                    " . $this->tblName . "
                ORDER BY
                    name";  
 
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
        // for ($i=0; $i < 10; $i++) { 
        // }
        $a = 0;
        while ($row =$stmt->fetch(PDO::FETCH_ASSOC)) {
            $this->setId($row['id']);
            $this->setName($row['name']);
            $this->setDescription($row['description']);
            $result[$a]['id'] = $this->getId();
            $result[$a]['name'] = $this->getName();
            $result[$a]['description'] = $this->getDescription();
            $a++;
        }
        return $result;
    }
    public function readOne($id){
        $this->setId($id);
        //select all data
        $query = "SELECT
                    id, name, description
                FROM
                    " . $this->tblName . "
                WHERE id  =
                    :id";  
 
        $stmt = $this->conn->prepare( $query );
        $id = $this->getId();
        $stmt->bindParam(':id', $id );
        $stmt->execute();
        while ($row =$stmt->fetch(PDO::FETCH_ASSOC)) {
            $this->setId($row['id']);
            $this->setName($row['name']);
            $this->setDescription($row['description']);
            $result['id'] = $this->getId();
            $result['name'] = $this->getName();
            $result['description'] = $this->getDescription();

        }
        return $result;
    }
    // used to read category name by its ID
    public function readName($id){
    $this->setId($id);
    $query = "SELECT name FROM " . $this->tblName . " WHERE id = ? limit 0,1";
    $id = $this->getId();
    $stmt = $this->conn->prepare( $query );
    $stmt->bindParam(1, $id);
    $stmt->execute();
    while ($row =$stmt->fetch(PDO::FETCH_ASSOC)) {
            $this->setName($row['name']);   
            $result = $this->getName();
        }
        return $result;
    }
    public function countAll(){
 
    $query = "SELECT id FROM " . $this->tblName . "";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    $num = $stmt->rowCount();
    return $num;
    }
    function create($name,$description){
    $this->setName($name);
    $this->setDescription($description);
        $query = "INSERT INTO " . $this->tblName . "
            SET name= :name,  description= :description";
        $stmt = $this->conn->prepare($query);
        $name = $this->getName();
        $description = $this->getDescription();
        // bind values 
        $stmt->bindParam(":name",$name  );
        $stmt->bindParam(":description",$description );
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    function delete($id){
        $this->setId($id);
        $query = "DELETE FROM " . $this->tblName . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $id = $this->getId();
        $stmt->bindParam(1, $id); 
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    function update($id,$name,$description){
        $this->setId($id);
        $this->setName($name);
        $this->setDescription($description);
        $query = "UPDATE
                " . $this->tblName . "
            SET
                name = :name ,
                description = :description 
               
            WHERE
                id = :id ";
 
        $stmt = $this->conn->prepare($query);
        // posted value
        // bind parameters
        $id  = $this->getId();
        $name = $this->getName();
        $description =  $this->getDescription();
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description',$description);
        $stmt->bindParam(':id', $id);
        

        if($stmt->execute()){
            return true;
        }
        else{
            return false;
        } 
    }
}
