<?php

class Sale{

	private $id;
    private $customer_id;
    private $user_id;
	private $product_id;
	private $total_items;
	private $proof;
	private $status;
	private $created;
	private $conn;
	public $tblName = "tbl_sale";
	private $none;
    private $nopic;
	

	function __construct($db,$none = "NaN", $nopic = "uploads/nopic.jpg"){
		$this->conn = $db;
		$this->setNone($none);
        $this->nopic = $nopic;
	}
	//get
	public function getId(){
		 if($this->id != ""){
            return $this->id;
        }
        else{
            return $this->none;
        } 
	}
    public function getCustomerId(){
         if($this->customer_id > 0  ){
            return $this->customer_id;
        }
        else{
            return $this->none;
        } 
    }
    public function getUserId(){
         if($this->user_id > 0  ){
            return $this->user_id;
        }
        else{
            return $this->none;
        } 
    }
    public function getNoPic(){
        if($this->nopic == ""){
           $this->nopic = "uploads/nopic.jpg";
        }
         return $this->nopic;
    }
	public function getProductId(){
		if($this->product_id > 0){
            return $this->product_id;
        }
        else{
            return 0;
        }
	}
	public function getTotalItems(){
		if($this->total_items > 0){
            return $this->total_items;
        }
        else{
            return 0;
        }
	}
	public function getProof(){
        if(is_file($this->proof)) {
            return $this->proof;
        }
        else{
            return $this->getNoPic();
        }        
    }
	public function getStatus(){
		if($this->status != ""){
            return $this->status;
        }
        else{
            return $this->none;
        }
	}
	public function getPrice(){
        if($this->price > 0){
            return $this->price;
        }
        else{
            return 0;
        }
    }
	 public function getCurentDate(){
        return date('Y-m-d H:i:s');
    } 
    public function getCreated(){
        if($this->created <= $this->getCurentDate()){
            return $this->created;
        }
        else{
            return $this->getCurentDate();
        }
    }
	///set
	public function setNone($none){
        $none = trim($none);
        if($none  != ""){
            $this->none = $none;
        }
        else{
            $this->none = "NaN";
        }
    }
	public function setId($id){
        $id = htmlspecialchars(strip_tags(trim($id)));
		if(trim($id) > 0){
			$this->id = $id ;
		}
	}
    public function setUserId($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->user_id = $var ;
        }
    }
    public function setCustomerId($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->customer_id = $var ;
        }
    }
    public function setProductId($id){
        $id = htmlspecialchars(strip_tags(trim($id)));
        if(trim($id) > 0){
            $this->product_id = $id ;
        }
    }
    public function setTotalItems($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) > 0){
            $this->total_items = $var ;
        }
    }
    public function setProof($image){
        if(is_file($image)){
            $this->proof = $image;
        }
        else {
            $this->proof = $this->getNoPic();
      }
    }
    public function setStatus($var){
         $var = htmlspecialchars(strip_tags(trim($var)));
        if(trim($var) != ""){
            $this->status = $var ;
        }
    }
    public function setCreated($var){
          if($var <= $this->getCurentDate()){
             $this->created= $var;
        }
        else{
           $this->created =  $this->getCurentDate();
        }
    }

	

	//
	
	public function countAll(){
 
    $query = "SELECT id FROM " . $this->tblName . "";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    $num = $stmt->rowCount();
 
    return $num;
}
	public function readOne($id){
		$this->setId($id);

		$query = "SELECT
		`id`, `customer_id`, `user_id`, `product_id`, `total_items`, `proof`, `status`, `created`
		   FROM " . $this->tblName . " WHERE id = :id ";
		$stmt = $this->conn->prepare( $query );
		$id = $this->getId();
	    $stmt->bindParam(':id', $id);
	    $stmt->execute();
 		
 		//
 		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
	        $this->setId($row['id']);
            $this->setCustomerId($row['customer_id']);
            $this->setUserId($row['user_id']);
            $this->setProductId($row['product_id']);
	        $this->setTotalItems($row['total_items']);
	        $this->setProof($row['proof']);
	        $this->setStatus($row['status']);
            $this->setCreated($row['created']);
	        $result['id'] = $this->getId();
            $result['customer_id'] = $this->getCustomerId();
            $result['user_id'] = $this->getUserId();
            $result['product_id'] = $this->getProductId();
	        $result['total_items'] = $this->getTotalItems();
	        $result['proof'] = $this->getProof();
	        $result['status'] = $this->getStatus();
            $result['created'] = $this->getCreated();
        }
        return $result; 
	}
	public function readAll(){
        //select all data
        $query = "SELECT
                  `id`, `customer_id`, `user_id`, `product_id`, `total_items`, `proof`, `status`, `created`
                FROM
                    " . $this->tblName . "
                    
                ORDER BY
                   date";  
 
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
 		$a = 0;
        while ($row =$stmt->fetch(PDO::FETCH_ASSOC)) {
	        $this->setId($row['id']);
            $this->setCustomerId($row['customer_id']);
            $this->setUserId($row['user_id']);
            $this->setProductId($row['product_id']);
            $this->setTotalItems($row['total_items']);
            $this->setProof($row['proof']);
            $this->setStatus($row['status']);
            $this->setCreated($row['created']);
            $result[$a]['id'] = $this->getId();
            $result[$a]['customer_id'] = $this->getCustomerId();
            $result[$a]['user_id'] = $this->getUserId();
            $result[$a]['product_id'] = $this->getProductId();
            $result[$a]['total_items'] = $this->getTotalItems();
            $result[$a]['proof'] = $this->getProof();
            $result[$a]['status'] = $this->getStatus();
            $result[$a]['created'] = $this->getCreated();
	        $a++;
        }
        return $result; 
    }
	 function Buy($customer_id, $product_id, $total_items){
        $this->setCustomerId($customer_id);
        $this->setProductId($product_id);
        $this->setTotalItems($total_items);
        $query = "INSERT INTO " . $this->tblName . "
            SET customer_id = :customer_id, product_id= :product_id ,  total_items= :total_items ";
        $stmt = $this->conn->prepare($query);
        $customer_id = $this->getCustomerId();
        $product_id = $this->getProductId();
        $total_items = $this->getTotalItems();
        // bind values 
        $stmt->bindParam(":customer_id",$customer_id  );
        $stmt->bindParam(":product_id",$product_id  );
        $stmt->bindParam(":total_items",$total_items );
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    function Accepted($id, $user_id){
        $this->setId($id);
        $this->setUserId($user_id);
        $query = "UPDATE " . $this->tblName . "
            SET user_id = :user_id, status= 'accepted' WHERE id = :id ";
        $stmt = $this->conn->prepare($query);
        $id = $this->getId();
        $user_id = $this->getUserId();
        // bind values 
        $stmt->bindParam(":user_id",$user_id  );
        $stmt->bindParam(":id",$id  );
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    function Canceled($id){
        $this->setId($id);
        $query = "UPDATE " . $this->tblName . "
            SET  status= 'canceled' WHERE id = :id ";
        $stmt = $this->conn->prepare($query);
        $id = $this->getId();
        // bind values 
        $stmt->bindParam(":id",$id  );
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    
    
  
    
 }