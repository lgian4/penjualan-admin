<?php

class User{

	private $id;
	private $username;
	private $password;
	private $level;
	private $name;
	private $address;
	private $phone;
	private $email;
	private $status;
	private $conn;
	public $tblName = "tbl_user";
	private $none;
	

	function __construct($db,$none = "NaN"){
		$this->conn = $db;
		 $this->setNone($none);
	}
	//get
	public function getId(){
		 if($this->id != ""){
            return $this->id;
        }
        else{
            return $this->none;
        } 
	}
	public function getUsername(){
		if($this->username != ""){
            return $this->username;
        }
        else{
            return $this->none;
        }
	}
	public function getPassword(){
		if($this->password!= ""){
            return $this->password;
        }
        else{
            return $this->none;
        }
	}
	public function getLevel(){
		if($this->level == "admin" ||  $this->level == "super"){
            return $this->level;
        }
        else{
            return $this->none;
        }
	}
	public function getName(){
		if($this->name != ""){
            return $this->name;
        }
        else{
            return $this->none;
        }
	}
	public function getAddress(){
		if($this->address != ""){
            return $this->address;
        }
        else{
            return $this->none;
        }
	}
	public function getPhone(){
		if($this->phone > 0 and $this->phone ){
            return $this->phone;
        }
        else{
            return $this->none;
        }
	}
	public function getEmail(){
		if($this->name != ""){
            return $this->name;
        }
        else{
            return $this->none;
        }
	}
	public function getStatus(){
		return  htmlspecialchars(strip_tags($this->status));
	}
	///set
	public function setNone($none){
        $none = trim($none);
        if($none  != ""){
            $this->none = $none;
        }
        else{
            $this->none = "NaN";
        }
    }
	public function setId($id){
		if(trim($id) != ""){
			$this->id = htmlspecialchars(strip_tags($id));
		}
	}
	public function setUsername($Username){
		if(trim($Username) != ""){
			$this->username = htmlspecialchars(strip_tags($Username));
		}
	}
	public function setPassword($password){
		if(trim($password) != ""){
			$this->password = htmlspecialchars(strip_tags($password));
		}
	}
	public function setLevel($level){
		if($level == "admin" ||  $level == "super"){
			$this->level = htmlspecialchars(strip_tags($level));
		}
	}
	public function setName($name){
		if(trim($name) != ""){
			$this->name = htmlspecialchars(strip_tags($name));
		}
	}
	public function setAddress($address){
		if(trim($address) != ""){
			$this->address = htmlspecialchars(strip_tags($address));
		}
	}
	public function setPhone($phone){
		if(trim($phone) != ""){
			$this->phone = htmlspecialchars(strip_tags($phone));
		}
	}
	public function setEmail($email){
		if(trim($email) != ""){
			$this->email = htmlspecialchars(strip_tags($email));
		}
	}
	public function setStatus($status){
		if(trim($status) != ""){
			$this->status = htmlspecialchars(strip_tags($status));
		}
	}

	//
	function login($username,$password)
	{
		$this->setUsername($username);
		$this->setPassword($password);
		$query = "SELECT *
		   FROM " . $this->tblName . " WHERE `username` =  :username and `password` = md5(:password) AND `status` =  'active' ";
		$stmt = $this->conn->prepare( $query );
		$username = $this->getUsername();
		$password = $this->getPassword();
	    $stmt->bindParam(":username", $username );
	    $stmt->bindParam(":password", $password);
	    //
	    
    	$stmt->execute();
 		while ($row =$stmt->fetch(PDO::FETCH_ASSOC)) {
	        $this->setId($row['id']);
	        $this->setUsername($row['username']);
	        $this->setPassword($row['password']);
	        $this->setLevel($row['level']);
	        $this->setName($row['name']);
	        $this->setAddress($row['address']);
	        $this->setPhone($row['phone']);
	        $this->setEmail($row['email']);
	        $this->setStatus($row['status']);
	        $result['id'] = $this->getId();
	        $result['username'] = $this->getUsername();
	        $result['password'] = $this->getPassword();
	        $result['level'] = $this->getLevel();
	        $result['name'] = $this->getName();
	        $result['address'] = $this->getAddress();
	        $result['phone'] = $this->getPhone();
	        $result['email'] = $this->getEmail();
	        $result['status'] = $this->getStatus();
	        
        }
        if (!isset($result)){
        	$result = false;
        }
        return $result; 
    	

	}
	public function countAll(){
 
    $query = "SELECT id FROM " . $this->tblName . "";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    $num = $stmt->rowCount();
 
    return $num;
}
	public function readOne($id){
		$this->setId($id);

		$query = "SELECT
		 id, username, password, level,name, address, phone,email, status
		   FROM " . $this->tblName . " WHERE id = :id ";
		$stmt = $this->conn->prepare( $query );
		$id = $this->getId();
	    $stmt->bindParam(':id', $id);
	    $stmt->execute();
 		
 		//
 		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
	        $this->setId($row['id']);
	        $this->setUsername($row['username']);
	        $this->setPassword($row['password']);
	        $this->setLevel($row['level']);
	        $this->setName($row['name']);
	        $this->setAddress($row['address']);
	        $this->setPhone($row['phone']);
	        $this->setEmail($row['email']);
	        $this->setStatus($row['status']);
	        $result['id'] = $this->getId();
	        $result['username'] = $this->getUsername();
	        $result['password'] = $this->getPassword();
	        $result['level'] = $this->getLevel();
	        $result['name'] = $this->getName();
	        $result['address'] = $this->getAddress();
	        $result['phone'] = $this->getPhone();
	        $result['email'] = $this->getEmail();
	        $result['status'] = $this->getStatus();
	        
        }
        return $result; 
	}
	public function readAll(){
        //select all data
        $query = "SELECT
                    id, username, level
                FROM
                    " . $this->tblName . "
                    WHERE status = 'active'
                ORDER BY
                    name";  
 
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
 		$a = 0;
        while ($row =$stmt->fetch(PDO::FETCH_ASSOC)) {
	        $this->setId($row['id']);
	        $this->setUsername($row['username']);
	        $this->setLevel($row['level']);
	        $result[$a]['id'] = $this->getId();
	        $result[$a]['username'] = $this->getUsername();
	        $result[$a]['level'] = $this->getLevel();
	        $a++;
        }
        return $result; 
    }
	 function create($username,$level){
    $this->setUsername($username);
    $this->setLevel($level);
        $query = "INSERT INTO " . $this->tblName . "
            SET username= :username,  level= :level,  password=md5('12345678') ";
        $stmt = $this->conn->prepare($query);
        $username = $this->getUsername();
        $level = $this->getLevel();
        // bind values 
        $stmt->bindParam(":username",$username  );
        $stmt->bindParam(":level",$level );
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    function delete($id){
        $this->setId($id);
        

        $query = "DELETE FROM " . $this->tblName . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $id = $this->getId();
        $stmt->bindParam(1, $id); 

        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    function disbled($id){
        $this->setId($id);
        $query = "UPDATE  " . $this->tblName . "  set status = 'nonactive' WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $id = $this->getId();
        $stmt->bindParam(1, $id); 
        if($result = $stmt->execute()){
            return true;
        }else{
            return false;
        }
    }
    function resetPassword($id, $oldPassword){
       	$id = htmlspecialchars(strip_tags($id));
        $oldPassword = htmlspecialchars(strip_tags($oldPassword));
        if ($this->readOne($id) && $this->getPassword() == $oldPassword){
        	 $this->setId($id);
        	$query = "UPDATE  " . $this->tblName . "  set password = md5('12345678') WHERE id = ?";
	        $stmt = $this->conn->prepare($query);
	        $id = $this->getId();
	        $stmt->bindParam(1, $id); 
	        if($result = $stmt->execute()){
	            return true;
	        }
        }
        else{
            return false;
        }
        
    }
    function changePassword($id,$oldPassword, $newPassword){
    	$id = htmlspecialchars(strip_tags($id));
        $oldPassword = htmlspecialchars(strip_tags($oldPassword));
        if ($this->readOne($id) && $this->getPassword() == $oldPassword){
	        $this->setId($id);
	        $this->setPassword($newPassword);

	        $query = "UPDATE  " . $this->tblName . "  set password = md5(:password) WHERE id = :id";
	        $stmt = $this->conn->prepare($query);
	        $id = $this->getId();
	        $password = $this->getPassword();
	        $stmt->bindParam(":password", $password); 
	        $stmt->bindParam(":id", $id); 
	        
	        if($result = $stmt->execute()){
	            return true;
	        }
    	}else{
            return false;
        }
    }
   
    function update($id,$name,$address,$phone,$email){
    	$this->setId($id);
        $this->setName($name);
        $this->setAddress($address);
        $this->setPhone($phone);
        $this->setEmail($email);
       
        $query = "UPDATE
                " . $this->tblName . "
            SET
                name = :name ,
                address = :address,
                phone = :phone,
                email = :email,
                
               
            WHERE
                id = :id ";
 
        $stmt = $this->conn->prepare($query);
        // posted value
        // bind parameters
        $id  = $this->getId();
        $name = $this->getName();
        $address = $this->getAddress();
        $phone = $this->getPhone();
        $email = $this->getEmail();
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':address',$address);
        $stmt->bindParam(':phone',$phone);
        $stmt->bindParam(':email',$email);
        $stmt->bindParam(':id', $id);
        

        if($stmt->execute()){
            return true;
        }
        else{
            return false;
        } 
    }
 }