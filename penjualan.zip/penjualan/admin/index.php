<?php
// core.php holds pagination variables
include_once '../config/core.php';
include_once '../config/database.php';
include_once '../objects/category.php';
include_once '../objects/user.php';
include_once '../objects/product.php';
include_once '../objects/stock.php';
include_once '../objects/consumer.php';
include_once '../objects/sale.php';
include_once '../objects/user.php';
// include database and object files

 
// instantiate database and product object

if($_SESSION['login'] == true){
	// $database = new Database();
	// $db = $database->getConnection();
 
	// $product = new Product($db);
	// $category = new Category($db);
	 
	$page_title = "welcome" . " - ".   $_SESSION['username'];
	include_once "layout_header.php";
	include_once "layout_menu.php";
	$database = new Database();
	$db = $database->getConnection();
	$category = new Category($db);
	$categoryCount = $category->countAll();
	$product = new product($db);
    $productCount = $product->countAll();
    $user = new User($db);
    $userCount  = $user->countAll();

	 
	// query products
	// $stmt = $product->readAll($from_record_num, $records_per_page);
	 
	// // specify the page where paging is used
	// $page_url = "index.php?";
	 
	// // count total rows - used for pagination
	// $total_rows=$product->countAll();
	 
	// // read_template.php controls how the product list will be rendered
	// include_once "read_template.php";
	 
	// layout_footer.php holds our javascript and closing html tags
	?>
<ul class="sidebar-menu">
        <li class="header">MENU</li>
        <!-- Optionally, you can add icons to the links -->
       <?php createNavList("home"); ?>
        
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>
	 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
    <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-sm-6 col-md-4">
        <div class="info-box bg-red">
          <span class="info-box-icon fa fa-list"></span>
          <div class="info-box-content">
            <span class="info-box-text">Category</span>
            <span class="info-box-number"><div class="tampil-jml-category"> <?php echo $categoryCount  ?></div></span>
          </div>
        </div>
      </div>

      <div class="col-sm-6 col-md-4">
        <div class="info-box bg-green">
          <span class="info-box-icon"><i class="fa fa-money"></i> </i></span>
          <div class="info-box-content">
            <span class="info-box-text">Product </span>
            <span class="info-box-number"><div class="tampil-jml-product"><?php echo $productCount; ?></div></span>
          </div>
        </div>
      </div>

      <div class="col-sm-6 col-md-4">
        <div class="info-box bg-blue">
          <span class="info-box-icon fa fa-users"></span>
          <div class="info-box-content">
            <span class="info-box-text">User</span>
            <span class="info-box-number"><div class="tampil-jml-user"><?php echo $userCount;?></div></span>
          </div>
        </div>
      </div>
    </div>

       


    <!-- Content Header (Page header) -->
   
    <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-sm-6 col-md-6">
        <div class="box box-danger">
          <div class="box-header with-border">
            <h3 class="box-title">Grafik Gender Siswa</h3>
            <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div>
          <div class="box-body">
            <canvas id="chart-pie-siswa" style="height:250px"></canvas>
            <ul class="chart-legend clearfix">
          </ul>
          </div>
        </div>
      </div>

      <div class="col-sm-6 col-md-6">
        <div class="box box-success">
          <div class="box-header with-border">
            <h3 class="box-title">Grafik Tahun Kelahiran Siswa</h3>
            <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div>
          <div class="box-body">
            <canvas id="chart-bar-siswa" style="height:250"></canvas>
          </div>
        </div>
      </div>

    </div>
    </section>
    <!-- /.content -->
  </div>

	<!-- AdminLTE App -->
	<script src="func/data-siswa.js"></script>
<script src="../libs/jquery/chartjs/Chart.min.js"></script>
<script src="func/grafik/chart-siswa.js"></script>
	<script src="../libs/adminlte/js/app.min.js"></script>
	<?php
	include_once "layout_footer.php";
}
else if($_SESSION['login'] == false){
	header("location:login.php");
}
