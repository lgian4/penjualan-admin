<?php
// core.php holds pagination variables
include_once '../config/core.php';

// include database and object files
 
// instantiate database and product object

if($_SESSION['login'] == true){
	// $database = new Database();
	// $db = $database->getConnection();
 
	// $product = new Product($db);
	// $category = new Category($db);
	 
	$page_title = "Product" . " - ".   $_SESSION['username'];
	include_once "layout_header.php";
	include_once "layout_menu.php";

	 
	// query products
	// $stmt = $product->readAll($from_record_num, $records_per_page);
	 
	// // specify the page where paging is used
	// $page_url = "index.php?";
	 
	// // count total rows - used for pagination
	// $total_rows=$product->countAll();
	 
	// // read_template.php controls how the product list will be rendered
	// include_once "read_template.php";
	 
	// layout_footer.php holds our javascript and closing html tags
	?>
  <ul class="sidebar-menu">
        <li class="header">MENU</li>
        <!-- Optionally, you can add icons to the links -->
        <?php createNavList("product");?>
        
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>
  
	  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1><i class="fa fa-glass"></i>Product</h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Product</li>
      </ol>
    </section>
    <!-- Main content -->
  <section class="content">
    <div class="row">
      

     

     
    </div>

       <div class="box box-success">
          <div class="box-header with-border">
            <h4 class="box-tittle"><i class="fa fa-table"></i> Data Product</h4>
              <div class="box-tools pull-right">
                  <a href="" data-toggle="modal" data-target="#modal-tambah-product"><button type="button" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Add Product</button></a>
              </div>
          </div>
          <div class="box-body">
          <div class="tampil-data-product"></div>
          </div>
        </div>
    </section>
      </div>
	<script > 
		$(document).ready(function(e) {

  tampil_data_product();

});
function tampil_data_product() {
  $.ajax({
    type: "GET",
    url: "func/tabel-data-product.php",
    success: function (data){
      $('.tampil-data-product').html(data)
    }
  });

  
}

function clear_product_tambah() {
  $("#id").val("");
  $("#description").val("");

}
function clear_product_update() {
  $("#nis_update").val("");
  $("#nama_update").val("");
  $("#tmpt_lahir_update").val("");
  $("#tgl_lahir_update").val("");
  $("#alamat_update").val("");
  $("#nama_ayah_update").val("");
  $("#nama_ibu_update").val("");
}
	</script>


	<!-- AdminLTE App -->
	<script src="../libs/adminlte/js/app.min.js"></script>
	<?php
	include_once "layout_footer.php";
}
else if($_SESSION['login'] == false){
	header("location:login.php");
}
