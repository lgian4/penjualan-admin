<?php
include 'koneksi.php';
include_once '../../config/database.php';
include_once '../../objects/product.php';
include_once '../../objects/category.php';
include_once '../../objects/user.php';
  $database = new Database();
  $db = $database->getConnection();
    $category = new Category($db);
$eks = $_GET['eks'];

if ($eks=="add") {
  $name = $_POST['name'];
  $description = $_POST['description'];

    $category->create($name,$description);

}

elseif ($eks=="delete") {
  $id = $_POST['id'];
$category->delete($id);
  $hapus->execute();
}

elseif ($eks=="detail") {
     $id = $_POST['id'];
    
     $data = $category->readOne($id);
    
   
     echo json_encode($data);
   }

elseif ($eks=="update") {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
   
$category->update($id,$name,$description);
   }



?>
