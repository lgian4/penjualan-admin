<?php
include 'koneksi.php';
include_once '../../config/database.php';
include_once '../../objects/product.php';
include_once '../../objects/category.php';
include_once '../../objects/user.php';
  $database = new Database();
  $db = $database->getConnection();
  $user = new User($db);
  $eks = $_GET['eks'];

if ($eks=="add") {
  $username = $_POST['username'];
  $level = $_POST['level'];
  if($level == 'admin' || $level == 'super'){
    $user->create($username,$level);
  }

}

elseif ($eks=="delete") {
  $id = $_POST['id'];
  $user->delete($id);
  
}

elseif ($eks=="detail") {
     $id = $_POST['id'];
    
     $data = $category->readOne($id);
    
   
     echo json_encode($data);
   }

elseif ($eks=="update") {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
   
   return $category->update($id,$name,$description);
   }



?>
