<?php

include_once '../../config/database.php';
include_once '../../objects/product.php';
include_once '../../objects/category.php';
include_once '../../objects/user.php';
  $database = new Database();
  $db = $database->getConnection();
  $product = new Product($db);
  $eks = $_GET['eks'];
if($eks == "upload"){
  if($_FILES['file']['name'] != ''){
    $test = explode('.', $_FILES['file']['name']);
    $extension = end($test); 
    
    $name = rand(100,9999999) . date("Ymdhis").rand(100,9999999) .'.'.$extension;
    
    $location = '../../uploads/'.$name;
    move_uploaded_file($_FILES['file']['tmp_name'], $location);

    echo $name;
}
}
if ($eks=="add") {
  $name = $_POST['name'];
  $description = $_POST['description'];
  //$image = $_FILES['file']['name'];
  $category = $_POST['category'];
  $image = $_POST['image'];
  
    $product->create($name,$description,$category,$image);



}

elseif ($eks=="delete") {
  $id = $_POST['id'];
$category->delete($id);
  $hapus->execute();
}

elseif ($eks=="detail") {
     $id = $_POST['id'];
    
     $data = $category->readOne($id);
    
   
     echo json_encode($data);
   }

elseif ($eks=="update") {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
   
$category->update($id,$name,$description);
   }


?>
