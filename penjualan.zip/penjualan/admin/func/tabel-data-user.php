<html>
  <head>

    <?php 

  
   
     
    // include database and object files
    include_once '../../config/core.php';
    include_once '../../config/database.php';
    include_once '../../objects/category.php';
    include_once '../../objects/user.php';
    include_once '../../objects/product.php';
    include_once '../../objects/stock.php';
    include_once '../../objects/consumer.php';
    include_once '../../objects/sale.php';
    include_once '../../objects/user.php';
    ?>
  </head>
  <body>
      <!--Awal Modal Tambah Siswa-->
        <div class="modal modal-primary" id="modal-tambah-user">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Add User</h3>
              </div>
              <div class="modal-body">
                <form class="form-horizontal">
                   
                      <div class="form-group">
                          <label for="" class="col-sm-3 control-label">Username</label>
                          <div class="col-sm-8">
                          <input type="text" class="form-control" id="username" maxlength="200" placeholder="Insert Username"" ">
                          </div>
                      </div>
                     
                      <div class="form-group">
                          <label for="" class="col-sm-3 control-label">Level</label>
                          <div class="col-sm-8">
                          <select class="form-control level" id='level' required >
                            <option value="" >Choose Level</option>
                            <option value="super">Super</option>
                            <option value="admin">Admin</option>
                          </select>
                            
                          </div>
                      </div>
                     
                      
                  </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary tambah-user" data-dismiss="modal">Save</button>
              </div>
            </div>
          </div>
        </div>
    <!--Akhir Modal Tambah Siswa-->

    <!--Awal Modal UPDATE Siswa-->
    <div class="modal modal-warning" id="modal-update-user">
      <div class="modal-dialog modal-warning">
        <div class="modal-content modal-warning">
          <div class="modal-header modal-warning">
            <button type="button " class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span></button>
            <h3 class="modal-title modal-warning">Detail User</h3>
          </div>
          <div class="modal-body modal-warning">
            <form class="form-horizontal">
                <div class="form-group">
                      <label for="" class="col-sm-3 control-label">User ID</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" id="id_update" maxlength="200" disabled="true">
                      </div>
                  </div>
                  <div class="form-group">
                      <label for="" class="col-sm-3 control-label">Username</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" id="name_update" maxlength="200" placeholder="Category Name">
                      </div>
                  </div>
                 
                  <div class="form-group">
                      <label for="" class="col-sm-3 control-label">Level</label>
                      <div class="col-sm-8">
                        <select required class="form-control level" id='level'>
                            <option >Choose Level</option>
                            <option value="super">Super</option>
                            <option value="admin">Admin</option>
                          </select>
                      </div>
                  </div>
                  
              </form>
          </div>
          <div class="modal-footer modal-warning">
            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-warning update-user" data-dismiss="modal">UPDATE</button>
          </div>
        </div>
      </div>
    </div>
    <!--Akhir Modal UPDATE Siswa-->
   

    <div class="table-responsive">
    <table class="table table-striped table-bordered data-user">
      <thead>
        <tr class="success">
          <th>ID</th>
          <th>Username</th>
          <th>Level</th>
         
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
      <?php
      $database = new Database();
      $db = $database->getConnection();
      $user = new User($db);
      $hasil = $user->readAll();
      $a = 0;
      while ( isset($hasil[$a]['id'])) { ?>
        <tr>
         <td><?php echo $hasil[$a]['id']; ?></td>
          <td><?php echo $hasil[$a]['username']; ?></td>
          <td><?php echo $hasil[$a]['level']; ?></td>
         
          <td><button type="button" name = "<?php echo $hasil[$a]["username"] ."||" .$hasil[$a]["level"]; ?> " id="<?php echo $hasil[$a]["id"]; ?>" class="btn btn-warning btn-sm detail-user" data-toggle="modal" data-target="#modal-update-user"><span class="glyphicon glyphicon-edit" aria-hidden="true"></button>
            <button type="button" id="<?php echo $hasil[$a]["id"]; ?>" class="btn btn-danger btn-sm hapus-user"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button>
            </td>
          
        </tr>
        <?php $a++;} ?>
      </tbody>
    </table>
  </div>
  </body>
</html>

<script type="text/javascript">
$(document).ready(function(e) {
  //CRUD data-siswa
  $('.tambah-user').click (function() {
   
    var username = $("#username").val().trim();
    var level = $("#level").val().trim();
    

    if (username=="") {
      alert("Username is Required");
    }
    else if(level=="") {
      alert("Level is Required");
    }
    else {
      $.ajax({
        type: "POST",
        url: "func/crud-user.php?eks=add",
        data: "username="+username+"&level="+level,
        success: function (msg) {
        tampil_data_user();
        clear_user_tambah();
        }
      });
    }
  });

  $('.hapus-user').click(function() {
    var id = this.id;
    var conf = confirm("Yakin Hapus user: " +id);
    if (conf==true) {
        $.ajax({
          type: "POST",
          url: "func/crud-user.php?eks=delete",
          data: "id="+id,
          success: function (msg) {
            tampil_data_user();
          }
        });
    }
  });

  $('.detail-category').click( function () {
    var id = this.id;
    var index =this.name.indexOf("|"); 
    var name = this.name.substring(0,index  );
    var description = this.name.substring(index + 2, this.name.lenght);
   
        $('#id_update').val(id);
        $('#name_update').val(name);
        $('#description_update').val(description);
    $.ajax({
      type: "POST",
      url: "func/crud-category.php?eks=detail",
      data: "id="+id,
      dataType: "json",
      success: function (data) {

        $('#id_update').val(id);
        $('#name_update').val(name);
        $('#description_update').val(data.description);
        $('#modal-update-siswa').modal("show");
      }
    });
  });

  $('.update-category').click(function () {
    var id = $("#id_update").val();
    var name = $("#name_update").val();
    var description = $('#description_update').val();
 
    $.ajax({
        type: "POST",
      url: "func/crud-category.php?eks=update",
        data: "id="+id+"&name="+name+"&description="+description,

        success: function (msg) {
        tampil_data_category();
        clear_category_update();

        }
    });
  });
$('.data-user').DataTable(); //datatables
});
</script>
