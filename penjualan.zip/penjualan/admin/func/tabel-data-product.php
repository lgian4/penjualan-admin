<html>
  <head>

    <?php 
   // include database and object files
    include_once '../../config/database.php';
    include_once '../../config/database.php';
    include_once '../../objects/category.php';
    include_once '../../objects/user.php';
    include_once '../../objects/product.php';
    include_once '../../objects/stock.php';
    include_once '../../objects/consumer.php';
    include_once '../../objects/sale.php';
    include_once '../../objects/user.php';
    ?>
  </head>
  <body>
      <!--Awal Modal Tambah Siswa-->
        <div class="modal modal-primary" id="modal-tambah-product">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Add Product</h3>
              </div>
              <div class="modal-body">
                <form class="form-horizontal" enctype="multipart/form-data">
                   
                      <div class="form-group">
                          <label for="" class="col-sm-3 control-label">Name</label>
                          <div class="col-sm-8">
                          <input type="text" class="form-control" id="name" maxlength="200" placeholder="Insert Product name"required>
                          </div>
                      </div>
                     
                      <div class="form-group">
                          <label for="" class="col-sm-3 control-label">Description</label>
                          <div class="col-sm-8">
                            <input type="text" class="form-control" id="description" maxlength="200" placeholder="Insert Description" required>
                          </div>
                      </div>
                      <div class="form-group">
                          <label for="" class="col-sm-3 control-label">Image</label>
                          <div class="col-sm-8">
                            <input type="file" class="form-control image" id="image" maxlength="200" placeholder="Insert Price" required>
                            <input type="text" class="form-control hidden " id="text-image" maxlength="200" disabled='true' >
                            <button type="button" class="btn btn-success upload-gambar" >Upload</button>
                          </div>
                      </div>
                      <div class="form-group">
                          <label for="" class="col-sm-3 control-label">Category</label>
                          <div class="col-sm-8">
                            <Select required id="category" class="form-control category">
                              <option value="">Please select</option>
                              <?php
                                $database = new Database();
                                $db = $database->getConnection();
                                $cateogry = new Category($db);
                                $hasil = $cateogry->readAll();
                                $a = 0;
                                
                                while (isset($hasil[$a]['id'])){
                                  echo "<option value='". $hasil[$a]['id'] ."'>".$hasil[$a]['name'] ."</option>";
                                  $a++;
                                }
                              ?>
                              
                            </Select> 
                          </div>
                      </div>
                     
                      
                  </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary tambah-product" data-dismiss="modal">Save</button>
              </div>
            </div>
          </div>
        </div>
    <!--Akhir Modal Tambah Siswa-->

    <!--Awal Modal UPDATE Siswa-->
    <div class="modal modal-warning" id="modal-update-product">
      <div class="modal-dialog modal-warning">
        <div class="modal-content modal-warning">
          <div class="modal-header modal-warning">
            <button type="button " class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span></button>
            <h3 class="modal-title modal-warning">Detail Category</h3>
          </div>
          <div class="modal-body modal-warning">
            <form class="form-horizontal">
                <div class="form-group">
                      <label for="" class="col-sm-3 control-label">Category ID</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" id="id_update" maxlength="200" disabled="true">
                      </div>
                  </div>
                  <div class="form-group">
                      <label for="" class="col-sm-3 control-label">Category Name</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" id="name_update" maxlength="200" placeholder="Category Name">
                      </div>
                  </div>
                 
                  <div class="form-group">
                      <label for="" class="col-sm-3 control-label">Description</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="description_update" maxlength="200" placeholder="Description">
                      </div>
                  </div>
                  
              </form>
          </div>
          <div class="modal-footer modal-warning">
            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-warning update-product" data-dismiss="modal">UPDATE</button>
          </div>
        </div>
      </div>
    </div>
    <!--Akhir Modal UPDATE Siswa-->
   

    <div class="table-responsive">
    <table class="table table-striped table-bordered data-product">
      <thead>
        <tr class="success">
          <th>ID</th>
          <th>Name</th>
          <th>Desciption</th>
          <th>Price</th>
          <th>Base Price</th>
          <th>Stock</th>
          <th>Image</th>
          <th>Category</th>
          <th>Aksi</th>

        </tr>
      </thead>

      <tbody>
      <?php
      $database = new Database();
      $db = $database->getConnection();
      $product = new product($db);
      $hasil = $product->readAll();
      $a = 0;
      while ( isset($hasil[$a]['id'])) { ?>
        <tr>
         <td><?php echo $hasil[$a]['id']; ?></td>
          <td><?php echo $hasil[$a]['name']; ?></td>
          <td><?php echo $hasil[$a]['description']; ?></td>
          <td><?php echo $hasil[$a]['price']; ?></td>
          <td><?php echo $hasil[$a]['base_price']; ?></td>
          <td><?php echo $hasil[$a]['stock']; ?></td>
          <td><img src="../uploads/<?php echo $hasil[$a]['image']; ?>""></td>
          <td><?php echo $hasil[$a]['category']; ?></td>

         
          <td><button type="button" name = "<?php echo $hasil[$a]["name"] ."||" .$hasil[$a]["description"]; ?>" id="<?php echo $hasil[$a]["id"]; ?>" class="btn btn-warning btn-sm detail-product" data-toggle="modal" data-target="#modal-update-product"><span class="glyphicon glyphicon-edit" aria-hidden="true"></button>
            <button type="button" id="<?php echo $hasil[$a]["id"]; ?>" class="btn btn-danger btn-sm hapus-product"><span class="glyphicon glyphicon-trash" aria-hidden="true"></button>
            </td>
          </td>
        </tr>
        <?php $a++; } ?>
      </tbody>
    </table>
  </div>
  </body>
</html>

<script type="text/javascript">
$(document).ready(function(e) {
  //CRUD data-siswa
  $(".upload-gambar").click(function() {
    var property = document.getElementById('image').files[0];
        var image_name = property.name;
        var image_extension = image_name.split('.').pop().toLowerCase();

        if(jQuery.inArray(image_extension,['gif','jpg','jpeg','']) == -1){
          alert("Invalid image file");
        }

        var form_data = new FormData();
        form_data.append("file",property);
        $.ajax({
          url:'func/crud-product.php?eks=upload',
          method:'POST',
          data:form_data,
          contentType:false,
          cache:false,
          processData:false,
          beforeSend:function(){
            $('.upload-gambar').html('Loading......');
          },
          success:function(data){
            $(".upload-gambar").addClass("hidden");
            $("#image").addClass("hidden");
            $("#text-image").removeClass("hidden").val(data);

          }
        });
  })//upload gambar
  $('.tambah-product').click (function() {
        
    var name = $("#name").val().trim();
    var description = $("#description").val().trim();
    var category = $("#category").val().trim();
        var image = $("#text-image").val().trim();

    

    if (name =="" ) {
      alert(" Name is Required" + name + description + category + form_data);
    }
    
    else {
      $.ajax({
        type: "POST",
        url: "func/crud-product.php?eks=add",
        data: "name="+name+"&description="+description+"&category="+category+"&image="+image,
        type: 'post',
        
        success: function (msg) {
        tampil_data_product();
        clear_product_tambah();
        }
      });
    }
  });

  $('.hapus-product').click(function() {
    var id = this.id;
    var conf = confirm("Yakin Hapus Category:" +id);
    if (conf==true) {
        $.ajax({
          type: "POST",
          url: "func/crud-product.php?eks=delete",
          data: "id="+id,
          success: function (msg) {
            tampil_data_category();
          }
        });
    }
  });

  $('.detail-product').click( function () {
    var id = this.id;
    var index =this.name.indexOf("|"); 
    var name = this.name.substring(0,index  );
    var description = this.name.substring(index + 2, this.name.lenght);
   
        $('#id_update').val(id);
        $('#name_update').val(name);
        $('#description_update').val(description);
    $.ajax({
      type: "POST",
      url: "func/crud-product.php?eks=detail",
      data: "id="+id,
      dataType: "json",
      success: function (data) {

        $('#id_update').val(id);
        $('#name_update').val(name);
        $('#description_update').val(data.description);
        $('#modal-update-siswa').modal("show");
      }
    });
  });

  $('.update-product').click(function () {
    var id = $("#id_update").val();
    var name = $("#name_update").val();
    var description = $('#description_update').val();
 
    $.ajax({
        type: "POST",
      url: "func/crud-product.php?eks=update",
        data: "id="+id+"&name="+name+"&description="+description,

        success: function (msg) {
        tampil_data_product();
        clear_product_update();

        }
    });
  });
$('.data-product').DataTable(); //datatables
});
</script>
