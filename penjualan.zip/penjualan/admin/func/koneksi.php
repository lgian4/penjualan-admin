<?php
try {
    $koneksi = New PDO ("mysql:host=localhost;dbname=dumping","root","");
} catch (Exception $e) {
    echo $e->getMessage();
}
?>
