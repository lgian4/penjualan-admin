
<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <title>Login</title>
 
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="../libs/bootstrap/css/bootstrap.min.css" />
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../libs/jquery/jquery-3.2.1.min.js"></script>
 
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="../libs/bootstrap/js/bootstrap.min.js"></script>

    <!-- our custom CSS -->
 

<link rel="stylesheet" href="../libs/jquery/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->


   <link rel="stylesheet" href="../libs/css/custom.css" />
</head>
<body>
 <div class="wrapper"><?php
include_once '../config/core.php';
include_once '../config/database.php';
include_once '../objects/user.php';

if(isset($_POST['submit'])){
	
		$username =  htmlspecialchars($_POST['username']);
		$password =  htmlspecialchars($_POST['password']);
		$database = new Database();
		$db = $database->getConnection();
		$user = new User($db);
		$hasil =$user->login($username,$password);

		if($hasil == true ){

			if($user->getLevel() == "super" || $user->getLevel() == "admin" ){
			$_SESSION["login"] = true;
			$_SESSION['username'] = $user->getUsername();
			$_SESSION['name'] = $user->getName();
			$_SESSION['level'] = $user->getLevel();
			header("location:index.php");
			}
		}
		
	}
if(!isset($_SESSION['login'] )){
	
	$page_title = "Penjualan Admin V.0.1 Beta";

	?>
	<?php if(isset($hasil) and $hasil == false){ ?>
	<div  class="modal error  fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog error">
			<div class="modal-content error">
				<div class="modal-header error ">
					<button type="button" class="close" data-dismiss="modal">
						<span aria-hidden="true">&times;</span>
						<span class="sr-only">Close</span>
					</button>
					<h4 class="modal-title error" id="myModalLabel">Login Failed</h4>
				</div>
				<!-- Body -->
				<div class="modal-body error">Username or Password Wrong</div>
				<div class="modal-footer error">
					<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>

				</div >
			</div >
		</div >
	</div >
	
	<?php } ?>
	
	<div class="row col-md-6 col-md-offset-3 col-xs-8 col-xs-offset-2">
	<div  style="margin-top: 20%;" class=" panel panel-primary">
	
	<div class='panel-heading panel-primary '  >
		<h2 clss='panel-title'>Login 
		</h2>
	</div>
	<div class="panel-body"> 
	<form action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"] ); ?>' method="post" >

<div class="form-group ">
<label for="inputusername" class="control-label">Username</label>
<input type="text" class="form-control" name="username" id="inputusername" placeholder="Username">
</div >
<div class="form-group">
<label for="inputpassword" class="control-label">Password</label>
<input type="password" class="form-control" name="password" id="inputpassword" placeholder="
Password">
</div >

<button type="submit" id="submit"  name="submit" class=" btnlogin btn btn-primary">Submit</button>

	</form>
	</div>
	</div><div class="alert alert-warning alert-dismissible" role="alert" style="background-color:#f39c12 !important;color:white;">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <strong>Default Password : 12345678</strong>
                     </div>
	</div>
	<script>
	$("#myModal").modal();

		$(document).ready( function(){
			var username = $("#inputusername");
		var password = $("#inputpassword");
		var usernameLabel = username.prev();
		var usernameParent = username.parent();
		var passwordLabel = password.prev();
		var passwordParent = password.parent();
		
		password.blur(function(){
			if(password.val().trim() == ''  ){
			
			passwordLabel.text("Please insert password !");
			passwordParent.addClass("has-error");
			passwordParent.removeClass("has-success");
			
			}else if( password.val().length <8){
			
			passwordLabel.text("password at least 8 characters");
			passwordParent.addClass("has-error");
			passwordParent.removeClass("has-success");
			
			}
			else{
			passwordLabel.text("password");
			passwordParent.removeClass("has-error");
			passwordParent.addClass("has-success");
			
		}
		});	//password
		username.blur(function(){
			if(username.val().trim() == ''  ){
			
			usernameLabel.text("Please insert Username !");
			usernameParent.addClass("has-error");
			usernameParent.removeClass("has-success");
			
		}else if( username.val().length <= 3){
			
			usernameLabel.text("Username must be more than 3 characters");
			usernameParent.addClass("has-error");
			usernameParent.removeClass("has-success");
			
		}else{
			usernameLabel.text("Username");
			usernameParent.removeClass("has-error");
			usernameParent.addClass("has-success");
			
		}
		});//username
		$(".btnlogin").click( function(){
		var hasilusername = true;
		var hasilpassword = true;
		if(username.val().trim() == ''  ){
			
			usernameLabel.text("Please insert Username !");
			usernameParent.addClass("has-error");
			usernameParent.removeClass("has-success");
			hasilusername = false;

		}else if( username.val().length <= 3){
			
			usernameLabel.text("Username must be more than 3 characters");
			usernameParent.addClass("has-error");
			usernameParent.removeClass("has-success");
			hasilusername = false;
		}else{
			usernameLabel.text("Username");
			usernameParent.removeClass("has-error");
			usernameParent.addClass("has-success");
			hasilusername = true;
		}
		if(password.val().trim() == ''  ){
			
			passwordLabel.text("Please insert password !");
			passwordParent.addClass("has-error");
			passwordParent.removeClass("has-success");
			hasilpassword = false;
		}else if( password.val().length <8){
			
			passwordLabel.text("password at least 8 characters");
			passwordParent.addClass("has-error");
			passwordParent.removeClass("has-success");
			hasilpassword = false;
		}else{
			passwordLabel.text("password");
			passwordParent.removeClass("has-error");
			passwordParent.addClass("has-success");
			hasilpassword = true;
		}
		if(hasilusername == true && hasilpassword == true){
			$this.prop("disable","true");
		}
		else{
			return false;
		}
		
			});//button click
		});// doc ready
	</script>
	</div></body></html>
	<?php
	






}
else{
	header("location:index.php");
}

?>