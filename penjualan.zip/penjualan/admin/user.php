<?php
// core.php holds pagination variables
include_once '../config/core.php';
 
// include database and object files
include_once '../config/database.php';
include_once '../objects/product.php';
include_once '../objects/category.php';
include_once '../objects/user.php';
 
// instantiate database and product object

if($_SESSION['login'] == true){
	// $database = new Database();
	// $db = $database->getConnection();
 
	// $product = new Product($db);
	// $category = new Category($db);
	 
	$page_title = "User" . " - ".   $_SESSION['username'];
	include_once "layout_header.php";
	include_once "layout_menu.php";

	 
	// query products
	// $stmt = $product->readAll($from_record_num, $records_per_page);
	 
	// // specify the page where paging is used
	// $page_url = "index.php?";
	 
	// // count total rows - used for pagination
	// $total_rows=$product->countAll();
	 
	// // read_template.php controls how the product list will be rendered
	// include_once "read_template.php";
	 
	// layout_footer.php holds our javascript and closing html tags
	?>
  <ul class="sidebar-menu">
        <li class="header">MENU</li>
        <!-- Optionally, you can add icons to the links -->
        <?php createNavList("user");?>
        
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>
  
	  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1><i class="fa fa-users"></i>User</h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">users</li>
      </ol>
    </section>
    <!-- Main content -->
  <section class="content">
    <div class="row">
      

     

     
    </div>
<div class="alert alert-warning alert-dismissible" role="alert">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <strong>Default Password : 12345678</strong>
                     </div>
       <div class="box box-success">
          <div class="box-header with-border">
            <h4 class="box-tittle"><i class="fa fa-table"></i> Data user</h4>
              <div class="box-tools pull-right">
                  <a href="" data-toggle="modal" data-target="#modal-tambah-user"><button type="button" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Add User</button></a>
              </div>
          </div>
          <div class="box-body">
          <div class="tampil-data-user"></div>
          </div>
        </div>
    </section>
      </div>
	<script > 
		$(document).ready(function(e) {

  tampil_data_user();

});
function tampil_data_user() {
  $.ajax({
    type: "GET",
    url: "func/tabel-data-user.php",
    success: function (data){
      $('.tampil-data-user').html(data)
    }
  });

  
}

function clear_user_tambah() {
  $("#user").val("");
  $("#level").val("");

}
function clear_user_update() {
  $("#nis_update").val("");
  $("#nama_update").val("");
  $("#tmpt_lahir_update").val("");
  $("#tgl_lahir_update").val("");
  $("#alamat_update").val("");
  $("#nama_ayah_update").val("");
  $("#nama_ibu_update").val("");
}
	</script>


	<!-- AdminLTE App -->
	<script src="../libs/adminlte/js/app.min.js"></script>
	<?php
	include_once "layout_footer.php";
}
else if($_SESSION['login'] == false){
	header("location:login.php");
}
