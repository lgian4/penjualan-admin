<header class="main-header">

    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>PP</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"></b>Penjualan</b> V.0.1</span>
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account Menu -->
          <li class="dropdown user user-menu">
            <!-- Menu Toggle Button -->
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <!-- The user image in the navbar-->
              <img src="../libs/adminlte/img/mahruskh.jpg" class=" user-image" alt="User Image">
              <!-- hidden-xs hides the username on small devices so only the image appears. -->
              <span class="hidden-xs"><?php echo $_SESSION['username'] ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- The user image in the menu -->
              <li class="user-header">
                <img src="../libs/adminlte/img/mahruskh.jpg" class="img-circle" alt="User Image">
                <p>
                  <?php echo $_SESSION['name'] ." - ".$_SESSION['level'] ?> 
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="../libs/adminlte/img/mahruskh.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php   echo $_SESSION['name'] ?></p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- search form (Optional) -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->

      <!-- Sidebar Menu -->
      

  <!-- Content Wrapper. Contains page content -->
 

 <?php
 function createNavList($nav){
  if($nav == "home"){
    echo '<li class="active" >';
  }
  else {
    echo "<li>";
  }
  echo '<a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>';
  if($nav == "category"){
    echo '<li class="active" >';
  }
  else {
    echo "<li>";
  }
  echo '<a href="category.php"><i class="fa fa-list"></i> <span>Category</span></a></li>';
  if($nav == "product"){
    echo '<li class="active" >';
  }
  else {
    echo "<li>";
  }
  echo '<a href="product.php"><i class="fa fa-glass"></i> <span>Product</span></a></li>';
  if($nav == "user"){
    echo '<li class="active" >';
  }
  else {
    echo "<li>";
  }
  echo '<a href="user.php"><i class="fa fa-users"></i> <span>User</span></a></li>';

 }
 ?>