<?php
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <title><?php echo $page_title; ?></title>
 
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="../libs/bootstrap/css/bootstrap.min.css" />
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../libs/jquery/jquery-3.2.1.min.js"></script>
 
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="../libs/bootstrap/js/bootstrap.min.js"></script>
<script src="../libs/jquery/datepicker/bootstrap-datepicker.js"></script>
<script src="../libs/jquery/datatables/jquery.dataTables.js"></script>
    <!-- our custom CSS -->
 
    <link rel="stylesheet" href="../libs/jquery/datepicker/datepicker3.css">
  <link rel="stylesheet" href="../libs/jquery/datatables/jquery.dataTables.css">
  <link rel="stylesheet" href="../libs/jquery/datatables/dataTables.bootstrap.css">
<link rel="stylesheet" href="../libs/jquery/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../libs/adminlte/css/AdminLTE.min.css">
 <link rel="stylesheet" href="../libs/adminlte/css/skins/skin-black.min.css">

   <link rel="stylesheet" href="../libs/css/custom.css" />
</head>
<body class="hold-transition skin-black sidebar-mini">
 <div class="wrapper">
    <!-- container -->
 
      
        <?php
        // show page header
        //echo "<div class='page-header'>
          //      <h1>{$page_title}</h1>
            //</div>";
        ?>
        
    <!-- /.content -->