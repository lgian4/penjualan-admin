<?php 
// include "config/database.php";
// include 'objects/stock.php';
// $database = new Database();
// $db = $database->getConnection();
// $stock= new Stock($db);
// $hasil = $stock->readAll();
// var_dump($hasil);
// print_r($hasil);




 
 ?>